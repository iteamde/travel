<?php

namespace App\Models\PagesCategories\Traits\Relationship;

use App\Models\PagesCategories\PagesCategories;


/**
 * Class PagesCategoriesRelationship.
 */
trait PagesCategoriesRelationship
{
    
}
